
# CognitiSched AI — Hackathon Prototype

A working front-end prototype derived from the supplied CognitiSched AI abstract and Campusathon 2026 rulebook.

## Prototype features
- Smart timetable generation with a deterministic constraint-aware baseline
- Hard constraint concepts: faculty availability, room capacity/type, batch collisions
- Cognitive-wellness protected periods
- Ranked timetable alternatives and explainable quality score
- Natural-language constraint assistant (prototype parser)
- What-if simulation and localized repair flow
- Interactive weekly calendar
- Resource and workload analytics
- Role selector: Admin / Faculty / Student
- CSV export and browser print-to-PDF
- CSV/Excel import UI placeholder for prototype demonstration
- Responsive desktop/tablet/mobile layout

## Run locally
1. Install Node.js 18+.
2. Run `npm install`
3. Run `npm run dev`
4. Open the URL printed by Vite.

## Hackathon next step
For the production architecture described in the abstract, replace/extend the client-side demo engine with:
- Python FastAPI optimization service
- OR-Tools CP-SAT
- PostgreSQL/Supabase
- real Excel/CSV parsing with Pandas
- LLM API only for translating natural language into structured constraints
- authenticated role-based backend

## Demo flow
Dashboard → Generate → Timetable → Assistant → What-if & Repair → Analytics → Export.

The prototype is intentionally transparent: it does not claim to use an LLM to generate schedules. The abstract specifies that the language model should translate requirements into constraints while the optimization engine creates the schedule.
