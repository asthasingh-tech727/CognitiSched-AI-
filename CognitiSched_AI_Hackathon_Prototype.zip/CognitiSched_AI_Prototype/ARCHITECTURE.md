
# CognitiSched AI — Architecture

Frontend
- React + Vite
- CSS design system
- Calendar, dashboards, analytics, forms

Production backend target
- Next.js API / Python FastAPI
- PostgreSQL / Supabase

Optimization pipeline
1. Validate imported/manual data
2. Reserve cognitive-wellness blocks
3. Build hard constraints
4. Backtracking + MRV feasibility search
5. CP-SAT optimization for soft constraints
6. Validate all hard constraints
7. Rank alternatives
8. Explain score
9. Persist schedule
10. Calendar/export/analytics

AI boundary
- LLM receives natural language requirements
- LLM returns structured constraints
- Solver remains responsible for schedule generation
