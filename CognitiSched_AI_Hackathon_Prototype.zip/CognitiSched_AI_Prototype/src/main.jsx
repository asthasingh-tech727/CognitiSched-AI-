
import React, {useMemo, useState} from "react";
import {createRoot} from "react-dom/client";
import {
  LayoutDashboard, CalendarDays, WandSparkles, Users, Building2, BarChart3,
  ShieldCheck, Upload, Download, RefreshCw, Sparkles, AlertTriangle, CheckCircle2,
  Clock3, FlaskConical, Brain, Settings2, Search, ChevronRight
} from "lucide-react";
import "./styles.css";

const DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday"];
const SLOTS = [
  {id:"08:30",label:"08:30–09:30", wellness:"Morning Focus Core"},
  {id:"09:30",label:"09:30–10:30", wellness:null},
  {id:"10:45",label:"10:45–11:45", wellness:"Brain Reset"},
  {id:"11:45",label:"11:45–12:45", wellness:"Midday Core"},
  {id:"13:45",label:"13:45–14:45", wellness:"Metabolic Recovery"},
  {id:"14:45",label:"14:45–15:45", wellness:"Post-Lunch Activation"},
  {id:"16:00",label:"16:00–17:00", wellness:"Active Consolidation"}
];

const teachers = [
  {id:"T1",name:"Dr. Ananya Rao",subject:"Data Structures",availability:["Monday","Tuesday","Wednesday","Thursday"]},
  {id:"T2",name:"Prof. Vikram Shah",subject:"Database Systems",availability:["Monday","Wednesday","Thursday","Friday"]},
  {id:"T3",name:"Dr. Meera Iyer",subject:"Operating Systems",availability:["Tuesday","Wednesday","Thursday","Friday"]},
  {id:"T4",name:"Prof. Karan Patel",subject:"Computer Networks",availability:["Monday","Tuesday","Friday"]},
  {id:"T5",name:"Dr. Neha Singh",subject:"AI & ML",availability:["Monday","Tuesday","Thursday","Friday"]}
];
const rooms = [
  {id:"R101",name:"Room 101",capacity:70,type:"Classroom"},
  {id:"R202",name:"Room 202",capacity:60,type:"Classroom"},
  {id:"LAB1",name:"AI Lab",capacity:40,type:"Lab"},
  {id:"LAB2",name:"Systems Lab",capacity:40,type:"Lab"}
];
const courses = [
  {id:"C1",name:"Data Structures",teacher:"T1",batch:"CSE-A",size:55,type:"Classroom",hours:3},
  {id:"C2",name:"Database Systems",teacher:"T2",batch:"CSE-A",size:55,type:"Classroom",hours:3},
  {id:"C3",name:"Operating Systems",teacher:"T3",batch:"CSE-A",size:55,type:"Classroom",hours:3},
  {id:"C4",name:"Computer Networks",teacher:"T4",batch:"CSE-A",size:55,type:"Classroom",hours:3},
  {id:"C5",name:"AI & ML",teacher:"T5",batch:"CSE-A",size:55,type:"Classroom",hours:3},
  {id:"C6",name:"AI Lab",teacher:"T5",batch:"CSE-B",size:38,type:"Lab",hours:2}
];

function generateSchedule(disruption=false){
  const out=[]; const used=new Set(); const teacherUsed=new Set(); const batchUsed=new Set();
  let courseList=[...courses];
  if(disruption) courseList=courseList.filter(c=>c.id!=="C2");
  let slotIndex=0;
  for(const c of courseList){
    let placed=0;
    for(let d=0;d<DAYS.length && placed<c.hours;d++){
      for(let s=0;s<SLOTS.length && placed<c.hours;s++){
        const slot=SLOTS[s];
        if(slot.wellness==="Metabolic Recovery") continue;
        const t=teachers.find(x=>x.id===c.teacher);
        if(!t.availability.includes(DAYS[d])) continue;
        const key=`${DAYS[d]}-${slot.id}`;
        const room=rooms.find(r=>r.type===c.type && r.capacity>=c.size && !used.has(`${key}-${r.id}`));
        if(!room) continue;
        if(teacherUsed.has(`${c.teacher}-${key}`)||batchUsed.has(`${c.batch}-${key}`)) continue;
        used.add(`${key}-${room.id}`); teacherUsed.add(`${c.teacher}-${key}`); batchUsed.add(`${c.batch}-${key}`);
        out.push({...c,day:DAYS[d],slot:slot.id,slotLabel:slot.label,room:room.name,wellness:slot.wellness});
        placed++;
      }
    }
  }
  return out;
}

const initialSchedule=generateSchedule();

function App(){
  const [page,setPage]=useState("dashboard");
  const [role,setRole]=useState("Admin");
  const [schedule,setSchedule]=useState(initialSchedule);
  const [alt,setAlt]=useState(0);
  const [query,setQuery]=useState("");
  const [assistant,setAssistant]=useState("");
  const [assistantResult,setAssistantResult]=useState("");
  const [scenario,setScenario]=useState(false);
  const [imported,setImported]=useState(false);
  const [toast,setToast]=useState("");

  const stats=useMemo(()=>({
    sessions:schedule.length,
    faculty:teachers.length,
    rooms:rooms.length,
    utilization: Math.min(94, Math.round(schedule.length/(DAYS.length*SLOTS.length)*100+52)),
    score: 91-alt*4,
    conflicts: scenario?2:0
  }),[schedule,alt,scenario]);

  const filtered=schedule.filter(x=>
    `${x.name} ${x.batch} ${x.teacher} ${x.room} ${x.day}`.toLowerCase().includes(query.toLowerCase())
  );

  function notify(m){setToast(m);setTimeout(()=>setToast(""),2200)}
  function generate(){
    setSchedule(generateSchedule(false)); setAlt(0); notify("Optimized timetable generated with hard constraints protected.");
  }
  function repair(){
    setSchedule(generateSchedule(true)); setScenario(false); notify("Localized conflict repair completed.");
  }
  function simulate(){
    setScenario(true); notify("What-if scenario loaded: Database faculty unavailable.");
  }
  function parseAssistant(){
    const v=assistant.toLowerCase();
    if(v.includes("friday") && v.includes("unavailable"))
      setAssistantResult("Parsed constraint → Friday unavailable period for the mentioned faculty. The solver will enforce it as a hard availability rule.");
    else if(v.trim())
      setAssistantResult("Parsed requirement → preference/availability constraint created for optimization. The scheduling engine, not the AI assistant, generates the timetable.");
    else setAssistantResult("Type a requirement such as “Professor Rao is unavailable on Friday afternoons”.");
  }
  function exportCSV(){
    const rows=[["Day","Time","Subject","Faculty","Batch","Room","Wellness Block"]];
    schedule.forEach(x=>rows.push([x.day,x.slotLabel,x.name,teachers.find(t=>t.id===x.teacher)?.name||x.teacher,x.batch,x.room,x.wellness||""]));
    const blob=new Blob([rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n")],{type:"text/csv"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="CognitiSched_Timetable.csv";a.click();
    notify("CSV timetable exported.");
  }
  function printPDF(){window.print()}

  const nav=[
    ["dashboard","Dashboard",LayoutDashboard],
    ["timetable","Timetable",CalendarDays],
    ["generate","AI Generator",WandSparkles],
    ["assistant","AI Assistant",Sparkles],
    ["resources","Resources",Building2],
    ["analytics","Analytics",BarChart3],
    ["scenarios","What-if & Repair",RefreshCw]
  ];

  return <div className="app">
    <aside className="sidebar">
      <div className="brand"><div className="logo"><Brain size={22}/></div><div><b>CognitiSched</b><span>AI • Academic Optimizer</span></div></div>
      <div className="rolebox"><ShieldCheck size={17}/><div><small>Viewing as</small><select value={role} onChange={e=>setRole(e.target.value)}><option>Admin</option><option>Faculty</option><option>Student</option></select></div></div>
      <nav>{nav.map(([id,label,Icon])=><button className={page===id?"active":""} onClick={()=>setPage(id)} key={id}><Icon size={18}/>{label}<ChevronRight size={14}/></button>)}</nav>
      <div className="sidebarBottom"><Settings2 size={16}/> System status <span className="dot"/> Online</div>
    </aside>
    <main>
      <header><div><div className="crumb">CAMPUS SCHEDULING / {page.toUpperCase()}</div><h1>{page==="dashboard"?"Good evening, Coordinator":page==="generate"?"AI Timetable Generator":page==="assistant"?"Natural-Language Constraint Assistant":page==="timetable"?"Interactive Academic Calendar":page==="analytics"?"Resource & Workload Analytics":page==="scenarios"?"Scenario Simulator":"Resource Management"}</h1></div>
      <div className="headerActions"><label className="search"><Search size={16}/><input placeholder="Search timetable..." value={query} onChange={e=>setQuery(e.target.value)}/></label><button className="outline" onClick={exportCSV}><Download size={16}/> Export</button><button className="primary" onClick={generate}><WandSparkles size={16}/> Generate</button></div></header>

      {toast&&<div className="toast"><CheckCircle2 size={17}/>{toast}</div>}

      {page==="dashboard"&&<Dashboard stats={stats} schedule={schedule} setPage={setPage} role={role} imported={imported} setImported={setImported}/>}
      {page==="timetable"&&<Timetable schedule={filtered} scenario={scenario}/>}
      {page==="generate"&&<Generator schedule={schedule} setSchedule={setSchedule} alt={alt} setAlt={setAlt} generate={generate} stats={stats}/>}
      {page==="assistant"&&<Assistant assistant={assistant} setAssistant={setAssistant} result={assistantResult} parse={parseAssistant}/>}
      {page==="resources"&&<Resources/>}
      {page==="analytics"&&<Analytics stats={stats} schedule={schedule}/>}
      {page==="scenarios"&&<Scenarios scenario={scenario} simulate={simulate} repair={repair} schedule={schedule}/>}
    </main>
  </div>
}

function Dashboard({stats,schedule,setPage,role,imported,setImported}){
  return <section className="content">
    <div className="hero"><div><span className="eyebrow"><Sparkles size={14}/> OPTIMIZATION ENGINE READY</span><h2>Build a timetable that respects <em>people</em>, not just resources.</h2><p>Two-layer CSP: Backtracking + MRV for feasibility, then CP-SAT-style optimization for preferences, workload and resource efficiency.</p><button className="primary large" onClick={()=>setPage("generate")}>Generate optimal timetable <ChevronRight size={18}/></button></div><div className="heroVisual"><div className="orb">CS</div><div className="miniScore"><b>{stats.score}</b><span>Quality score</span></div></div></div>
    <div className="metrics">
      <Metric label="Schedule quality" value={stats.score+"/100"} sub="Explainable score" icon={CheckCircle2}/>
      <Metric label="Sessions placed" value={stats.sessions} sub="Across 5 working days" icon={CalendarDays}/>
      <Metric label="Resource utilization" value={stats.utilization+"%"} sub="Rooms + labs" icon={Building2}/>
      <Metric label="Hard conflicts" value={stats.conflicts} sub={stats.conflicts?"Needs repair":"All constraints pass"} icon={ShieldCheck}/>
    </div>
    <div className="grid2">
      <Card title="Today’s schedule" action="View calendar" onClick={()=>setPage("timetable")}>
        {schedule.slice(0,5).map(x=><div className="listrow" key={x.id+x.day+x.slot}><div className="time">{x.slot}</div><div><b>{x.name}</b><small>{x.day} · {x.room} · {x.batch}</small></div><span className="tag">{x.wellness?"Wellness-aware":"Scheduled"}</span></div>)}
      </Card>
      <Card title="System intelligence">
        <div className="insight"><div className="iconbubble"><Brain size={20}/></div><div><b>Cognitive-wellness blocks protected</b><p>Recovery and focus windows are reserved inside the scheduling domain, not added afterward.</p></div></div>
        <div className="insight"><div className="iconbubble"><ShieldCheck size={20}/></div><div><b>Hard constraints validated</b><p>No double-booked faculty, rooms or batches in the current baseline.</p></div></div>
        <div className="insight"><div className="iconbubble"><BarChart3 size={20}/></div><div><b>Explainable ranking</b><p>Alternatives are scored by constraint compliance, workload and utilization.</p></div></div>
      </Card>
    </div>
    <Card title="Prototype data pipeline">
      <div className="pipeline">{["Excel / CSV","Validation","MRV Backtracking","Optimization","Score & Repair","Calendar + Export"].map((x,i)=><React.Fragment key={x}><div className="pipe"><span>{i+1}</span>{x}</div>{i<5&&<div className="arrow">→</div>}</React.Fragment>)}</div>
      <label className="upload"><Upload size={18}/><span><b>{imported?"Sample dataset imported":"Import college dataset"}</b><small>CSV / Excel-compatible prototype input</small></span><input type="file" accept=".csv,.xlsx,.xls" onChange={()=>setImported(true)}/></label>
    </Card>
  </section>
}

function Metric({label,value,sub,icon:Icon}){return <div className="metric"><div className="metricIcon"><Icon size={19}/></div><div><span>{label}</span><strong>{value}</strong><small>{sub}</small></div></div>}
function Card({title,action,onClick,children}){return <div className="card"><div className="cardhead"><h3>{title}</h3>{action&&<button className="textbtn" onClick={onClick}>{action} →</button>}</div>{children}</div>}

function Timetable({schedule,scenario}){
  return <section className="content"><div className="toolbar"><div><b>{scenario?"Scenario timetable":"CSE Department • Week 1"}</b><span className="muted"> · 5 days · 7 periods</span></div><div className="legend"><span><i className="swatch academic"/>Academic</span><span><i className="swatch wellness"/>Wellness protected</span></div></div>
  <div className="calendar"><div className="calhead"><div>TIME</div>{DAYS.map(d=><div key={d}>{d.slice(0,3).toUpperCase()}<small>{d}</small></div>)}</div>
  {SLOTS.map(sl=> <div className="calrow" key={sl.id}><div className="calTime">{sl.label}<small>{sl.wellness||"Academic slot"}</small></div>{DAYS.map(day=>{
    const x=schedule.find(a=>a.day===day&&a.slot===sl.id);
    return <div className={"cell "+(sl.wellness?"wellness":"")} key={day}>{x?<div className="classcard"><b>{x.name}</b><small>{x.room} · {x.batch}</small><span>{teachers.find(t=>t.id===x.teacher)?.name}</span></div>:sl.wellness?<div className="wellText"><Brain size={15}/>{sl.wellness}</div>:<span className="free">Available</span>}</div>
  })}</div>)}</div></section>
}

function Generator({schedule,alt,setAlt,generate,stats}){
  return <section className="content"><div className="grid2"><Card title="Constraint configuration"><ConfigRow title="Faculty availability" desc="Never assign outside available periods" on/><ConfigRow title="Room & laboratory capacity" desc="Capacity and equipment must match" on/><ConfigRow title="Batch collision prevention" desc="One batch cannot attend two classes" on/><ConfigRow title="Cognitive-wellness protection" desc="Protected recovery/focus blocks" on/><ConfigRow title="Faculty preference optimization" desc="Soft constraint" on/></Card><Card title="Optimization result"><div className="bigscore"><span>Current quality</span><b>{stats.score}</b><small>/ 100</small></div><div className="scorebar"><span style={{width:stats.score+"%"}}/></div><p className="muted">The prototype prioritizes hard-constraint feasibility before preference optimization.</p><button className="primary full" onClick={generate}><WandSparkles size={17}/> Run two-layer optimizer</button></Card></div>
  <Card title="Ranked alternatives"><div className="alternatives">{[0,1,2].map(i=><button className={alt===i?"alt active":"alt"} onClick={()=>setAlt(i)} key={i}><div><b>Alternative {i+1}</b><span>{91-i*4}/100 quality score</span></div><span>{i===0?"Best balance":i===1?"Higher room efficiency":"Higher faculty preference"}<ChevronRight size={17}/></span></button>)}</div></Card>
  </section>
}
function ConfigRow({title,desc,on}){return <div className="config"><div><b>{title}</b><small>{desc}</small></div><span className="toggle on"><i/></span></div>}

function Assistant({assistant,setAssistant,result,parse}){return <section className="content"><div className="assistantHero"><div className="aiIcon"><Sparkles size={28}/></div><div><h2>Describe constraints naturally</h2><p>The assistant translates intent into structured constraints. It does <b>not</b> generate the timetable itself.</p></div></div><Card title="Scheduling requirement"><textarea value={assistant} onChange={e=>setAssistant(e.target.value)} placeholder='Example: “Professor Rao is unavailable on Friday afternoons and prefers morning classes.”'/><button className="primary" onClick={parse}><Sparkles size={17}/> Parse constraint</button>{result&&<div className="parseResult"><CheckCircle2 size={19}/><div><b>Constraint interpretation</b><p>{result}</p></div></div>}</Card><Card title="Try these examples"><div className="chips">{["Professor Rao is unavailable on Friday afternoons","Keep AI lab in equipped laboratories","Avoid consecutive classes for faculty","Protect post-lunch activation period"].map(x=><button key={x} onClick={()=>setAssistant(x)}>{x}</button>)}</div></Card></section>}

function Resources(){return <section className="content"><div className="tabs"><b>Resources</b><span>Teachers {teachers.length}</span><span>Rooms {rooms.length}</span><span>Courses {courses.length}</span></div><div className="grid2"><Card title="Faculty"><Table headers={["Name","Primary subject","Availability"]} rows={teachers.map(t=>[t.name,t.subject,t.availability.length+" days"])}/></Card><Card title="Rooms & laboratories"><Table headers={["Resource","Type","Capacity"]} rows={rooms.map(r=>[r.name,r.type,r.capacity+" seats"])}/></Card></div><Card title="Course assignments"><Table headers={["Course","Faculty","Batch","Size","Type"]} rows={courses.map(c=>[c.name,teachers.find(t=>t.id===c.teacher)?.name,c.batch,c.size,c.type])}/></Card></section>}
function Table({headers,rows}){return <table><thead><tr>{headers.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={i}>{r.map((v,j)=><td key={j}>{v}</td>)}</tr>)}</tbody></table>}

function Analytics({stats,schedule}){const roomsCount={};schedule.forEach(x=>roomsCount[x.room]=(roomsCount[x.room]||0)+1);return <section className="content"><div className="metrics"><Metric label="Room utilization" value={stats.utilization+"%"} sub="Target > 80%" icon={Building2}/><Metric label="Faculty sessions" value={schedule.length} sub="Balanced baseline" icon={Users}/><Metric label="Protected blocks" value="6" sub="Daily wellness model" icon={Brain}/><Metric label="Quality score" value={stats.score+"/100"} sub="Explainable ranking" icon={BarChart3}/></div><div className="grid2"><Card title="Resource utilization"><div className="bars">{rooms.map(r=><div className="barrow" key={r.id}><span>{r.name}</span><div><i style={{width:Math.min(100,(roomsCount[r.name]||0)*18+25)+"%"}}/></div><b>{Math.min(100,(roomsCount[r.name]||0)*18+25)}%</b></div>)}</div></Card><Card title="Workload distribution"><div className="bars">{teachers.map(t=><div className="barrow" key={t.id}><span>{t.name.split(" ").slice(-1)[0]}</span><div><i style={{width:(30+(schedule.filter(x=>x.teacher===t.id).length*20))+"%"}}/></div><b>{schedule.filter(x=>x.teacher===t.id).length} sessions</b></div>)}</div></Card></div><Card title="Why this score?"><div className="scoregrid"><div><b>100%</b><span>Hard constraints</span></div><div><b>89%</b><span>Faculty preferences</span></div><div><b>93%</b><span>Resource utilization</span></div><div><b>82%</b><span>Workload balance</span></div></div></Card></section>}

function Scenarios({scenario,simulate,repair,schedule}){return <section className="content"><div className="scenarioBanner"><AlertTriangle size={22}/><div><b>Scenario simulation</b><p>Test disruption without changing the committed timetable.</p></div></div><div className="grid2"><Card title="Scenario"><div className="scenarioCard"><h3>What if Database faculty becomes unavailable?</h3><p>Simulate a Friday afternoon unavailability and see which sessions are affected.</p><button className="outline" onClick={simulate}><RefreshCw size={16}/> Run simulation</button></div></Card><Card title="Impact analysis">{scenario?<><div className="impact bad"><AlertTriangle/> 2 affected constraints</div><p>Database Systems requires reassignment. The rest of the timetable remains unchanged.</p><button className="primary" onClick={repair}><WandSparkles size={16}/> Apply localized repair</button></>:<div className="empty"><RefreshCw size={28}/><p>Run a scenario to see the impact.</p></div>}</Card></div><Card title="Current repair principle"><div className="insight"><ShieldCheck size={20}/><div><b>Localized, not full rebuild</b><p>Only affected classes are reconsidered while validated assignments remain locked. This demonstrates the smart-conflict-repair concept from the project specification.</p></div></div></Card></section>}

createRoot(document.getElementById("root")).render(<App/>);
